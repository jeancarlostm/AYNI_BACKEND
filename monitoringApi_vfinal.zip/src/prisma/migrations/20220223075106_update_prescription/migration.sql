-- AlterTable
ALTER TABLE `prescription` MODIFY `instructions` VARCHAR(250) NULL;
