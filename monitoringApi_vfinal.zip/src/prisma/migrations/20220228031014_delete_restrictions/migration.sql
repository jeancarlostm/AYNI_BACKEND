-- AlterTable
ALTER TABLE `dailyreport` MODIFY `temperature` DECIMAL(65, 30) NULL,
    MODIFY `saturation` DECIMAL(65, 30) NULL,
    MODIFY `heartRate` DECIMAL(65, 30) NULL;
